﻿
$(document).ready(function () {

    $('#dataTable').dataTable();

    $('#btnLoad').click(function () {
        alert("Test");
    });

  

    //$.ajax({
    //    url: "/Student/List",
    //    type: "GET",
    //    contentType: "application/json;charset=utf-8",
    //    //dataType: "json",
    //    success: function (result) {
    //        var html = '';
    //        $.each(result, function (key, item) {
    //            html += '<tr>';
    //            html += '<td>' + item.Name + '</td>';
    //            html += '<td>' + item.Address + '</td>';
    //            html += '<td>' + item.Contact + '</td>';
    //            html += '<td>' + item.Fees + '</td>';
    //            html += '<td><a href="#" onclick="return getById(' + item.Id + ')">Edit</a> |<a href="#" onclick="Delete(' + item.Id + ')">Delete</a></td>';
    //            html += '</tr>';
    //        });
    //        $('#dataTable tbody').html(html);
    //    },
    //    error: function (ex) {
    //        alert(ex.responseText);
    //    }
    //});



    //var oTable = $('#dataTable').DataTable({
    //    "ajax": {
    //        "url": "/Student/List",
    //        "type": "get",
    //        "datatype": "json"
    //    },
    //    "columns": [

    //        { "data": "Name", "autoWidth": true },
    //        { "data": "Address", "autoWidth": true },
    //        { "data": "Contact", "autoWidth": true },
    //        { "data": "Fess", "autoWidth": true },
    //        {
    //            "data": "ID", "width": "50px", "render": function (data) {
    //                return '<a class="popup" href="/Home/Save/' + data + '">Edit</a>';
    //            }
    //        },
    //        {
    //            "data": "ID", "width": "50px", "render": function (data) {
    //                return '<a class="popup" href="/Home/Delete/' + data + '">Delete</a>';
    //            }
    //        }
    //    ]
    //})
});

//function loadData() {
//    debugger
//    $.ajax({
//        url: "/Student/List",
//        type: "GET",
//        contentType: "application/json;charset=utf-8",
//        //dataType: "json",
//        success: function (result) {
//            var html = '';
//            $.each(result, function (key, item) {
//                html += '<tr>';
//                html += '<td>' + item.Name + '</td>';
//                html += '<td>' + item.Address + '</td>';
//                html += '<td>' + item.Contact + '</td>';
//                html += '<td>' + item.Fees + '</td>';
//                html += '<td><a href="#" onclick="return getById(' + item.Id + ')">Edit</a> |<a href="#" onclick="Delete(' + item.Id + ')">Edit</a></td>';
//                html += '</tr>';
//            });
//            $('#dataTable tbody').html(html);
//        },
//        error: function (ex) {
//            alert(ex.responseText);
//        }
//    });
//}

$.ajax({
    url: "/Student/List",
    type: "GET",
    contentType: "application/json;charset=utf-8",
    dataType: "json",
    success: function (data) {
        $('#dataTable').dataTable({
            data: data,
            column: [
                { 'data': 'Name' },
                { 'data': 'Address' },
                { 'data': 'Contact' },
                { 'data': 'Fess' },
                { 'data': '<a href="#" onclick="return getById(' + item.Id + ')">Edit</a> |<a href="#" onclick="Delete(' + item.Id + ')">Edit</a>' },
            ]
        });
        //$('#dataTable tbody').html(html);
    },
    error: function (ex) {
        alert(ex.responseText);
    }
});
