﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CRUDAjax.Models;
using System.Data;

namespace CRUDAjax.Controllers
{
    public class StudentController : Controller
    {
        //
        // GET: /Student/
        StudentContext studentContext = new StudentContext();
        
        
        public ActionResult List()
        {
            List<Student> students = studentContext.Students.ToList();
            return Json(students, JsonRequestBehavior.AllowGet);
            //return View();
        }

        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Add()
        {           
            return View();
        }


        [HttpPost]
        public JsonResult Add(Student student) 
        {
            studentContext.Students.Add(student);
            studentContext.SaveChanges();
            string message = "Success";
            return Json(new { Message=message}, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Update()
        {
            return View();
        }

        
        public JsonResult GetById(int id)
        {
            Student student = studentContext.Students.Find(id);
            return Json(student, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Delete(int id)
        {
            Student student = studentContext.Students.Find(id);
            studentContext.Students.Remove(student);
            studentContext.SaveChanges();
            string message = "Success";
            return Json(new { Message = message }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Update(Student Student)
        {
            studentContext.Entry(Student).State = EntityState.Modified;
            studentContext.SaveChanges();
            string message = "Updated";
            return Json(new { Message = message }, JsonRequestBehavior.AllowGet);
        }


    }
}
